This project has now been officially merged upstream into Gifsicle, so please use that: https://github.com/kohler/gifsicle
